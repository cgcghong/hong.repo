MELK_IP="192.168.10.167"        #Management IP
MIRROR_INTERFACE="ens224"       #Mirroring Interface ID
ES_RETAINNUMHOURS="24"           #Elasticsearch Data Storing Hours(ex:1day="24",7day="168" ...)


# OS Setting -------------------------------------------------------------------------------------------------------------------------------------------
timedatectl set-timezone Asia/Seoul
grep -q "58 23 * * * docker exec moloch-capture /data/moloch/db/hourly.sh" /var/spool/cron/root || echo "58 23 * * * docker exec moloch-capture /data/moloch/db/hourly.sh" >> /var/spool/cron/root
systemctl restart crond
sysctl -w vm.max_map_count=262144
# ------------------------------------------------------------------------------------------------------------------------------------------------------


# Configuration Files Setting --------------------------------------------------------------------------------------------------------------------------
sed -i "s/interface=.*/interface=$MIRROR_INTERFACE/" /melk/config/config.ini
sed -i "s/elasticsearch=http.*/elasticsearch=http\:\/\/$MELK_IP:9200/" /melk/config/config.ini
sed -i "s/viewUrl = https.*/viewUrl = https\:\/\/$MELK_IP:8005/" /melk/config/config.ini
sed -i "s/\/data\/moloch\/db\/db.pl.*/\/data\/moloch\/db\/db.pl $MELK_IP:9200 expire hourly $ES_RETAINNUMHOURS/" /melk/config/hourly.sh
sed -i "s/ES_HOST=.*/ES_HOST=$MELK_IP/" /melk/config/docker-compose.yaml
sed -i "s/ES_HOST=.*/ES_HOST=$MELK_IP/" /melk/config/docker-compose.init.yaml
sed -i "s/ELASTICSEARCH_HOSTS.*/ELASTICSEARCH_HOSTS:http:\/\/$MELK_IP:9200/" /melk/config/docker-compose.yaml
sed -i "s/ELASTICSEARCH_HOSTS.*/ELASTICSEARCH_HOSTS:http:\/\/$MELK_IP:9200/" /melk/config/docker-compose.init.yaml
useradd elasticsearch
ES_ID=$(id -u elasticsearch)
sed -i "s/user: \"0.*/user: \"0:$ES_ID\"/" /melk/config/docker-compose.yaml
sed -i "s/user: \"0.*/user: \"0:$ES_ID\"/" /melk/config/docker-compose.init.yaml
# -------------------------------------------------------------------------------------------------------------------------------------------------------


# Mirroring Interface Setting ---------------------------------------------------------------------------------------------------------------------------
yum -y install net-tools
chmod +x /etc/rc.d/rc.local
grep -q "sudo ip link set $MIRROR_INTERFACE promisc on" /etc/rc.d/rc.local || echo "sudo ip link set $MIRROR_INTERFACE promisc on" >> /etc/rc.d/rc.local
grep -q "sudo ip link set dev $MIRROR_INTERFACE arp off" /etc/rc.d/rc.local || echo "sudo ip link set dev $MIRROR_INTERFACE arp off" >> /etc/rc.d/rc.local
#grep -q "sudo ethtool -G $MIRROR_INTERFACE rx 4096" /etc/rc.d/rc.local || echo "sudo ethtool -G $MIRROR_INTERFACE rx 4096" >> /etc/rc.d/rc.local
#grep -q "sudo ethtool -G $MIRROR_INTERFACE tx 4096" /etc/rc.d/rc.local || echo "sudo ethtool -G $MIRROR_INTERFACE tx 4096" >> /etc/rc.d/rc.local
grep -q "sudo ethtool -K $MIRROR_INTERFACE tx off" /etc/rc.d/rc.local || echo "sudo ethtool -K $MIRROR_INTERFACE tx off" >> /etc/rc.d/rc.local
grep -q "sudo ethtool -K $MIRROR_INTERFACE sg off" /etc/rc.d/rc.local || echo "sudo ethtool -K $MIRROR_INTERFACE sg off" >> /etc/rc.d/rc.local
grep -q "sudo ethtool -K $MIRROR_INTERFACE tso off" /etc/rc.d/rc.local || echo "sudo ethtool -K $MIRROR_INTERFACE tso off" >> /etc/rc.d/rc.local
grep -q "sudo ethtool -K $MIRROR_INTERFACE ufo off" /etc/rc.d/rc.local || echo "sudo ethtool -K $MIRROR_INTERFACE ufo off" >> /etc/rc.d/rc.local
grep -q "sudo ethtool -K $MIRROR_INTERFACE gso off" /etc/rc.d/rc.local || echo "sudo ethtool -K $MIRROR_INTERFACE gso off" >> /etc/rc.d/rc.local
grep -q "sudo ethtool -K $MIRROR_INTERFACE gro off" /etc/rc.d/rc.local || echo "sudo ethtool -K $MIRROR_INTERFACE gro off" >> /etc/rc.d/rc.local
grep -q "sudo ethtool -K $MIRROR_INTERFACE lro off" /etc/rc.d/rc.local || echo "sudo ethtool -K $MIRROR_INTERFACE lro off" >> /etc/rc.d/rc.local
source /etc/rc.d/rc.local
sudo ethtool -G $MIRROR_INTERFACE rx 2047
sudo ethtool -G $MIRROR_INTERFACE rx 4096
# -------------------------------------------------------------------------------------------------------------------------------------------------------

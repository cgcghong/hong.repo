DB=/dev/sdb              #Elasticsearch 데이터를 저장할 공간
PCAP=/dev/sdc            #PCAP 데이터를 저장할 공간
DB_SIZE_GB=10            #GigaByte 단위로 작성
PCAP_SIZE_GB=20          #GigaByte 단위로 작성

# 초기화------------------------------------------------------------------------------------------
DB1=$DB'1'
PCAP1=$PCAP'1'
umount $DB1
umount $PCAP1
sed -i '/#DB/d' /etc/fstab
sed -i '/\/melk\/DB/d' /etc/fstab
sed -i '/#PCAP/d' /etc/fstab
sed -i '/\/melk\/PCAP/d' /etc/fstab
parted -s $DB rm 1
parted -s $PCAP rm 1
# ------------------------------------------------------------------------------------------------

# 파티션/파일시스템 구성--------------------------------------------------------------------------
parted -s $DB mklabel gpt unit GB mkpart primary 0.00 $DB_SIZE_GB print
parted -s $PCAP mklabel gpt unit GB mkpart primary 0.00 $PCAP_SIZE_GB print
sleep 1
mkfs.ext4 $DB1
sleep 1
UUID1=$(ls -l /dev/disk/by-uuid | grep -Go "\\S\+\( -> ../../${DB1:5:4}\)")
UUID1=${UUID1:0:36}
echo \#DB >> /etc/fstab
echo UUID=$UUID1 /melk/DB                   ext4     defaults        1 1 >> /etc/fstab

sleep 1
mkfs.ext4 $PCAP1
UUID2=$(ls -l /dev/disk/by-uuid | grep -Go "\\S\+\( -> ../../${PCAP1:5:4}\)")
UUID2=${UUID2:0:36}
echo \#PCAP >> /etc/fstab
echo UUID=$UUID2 /melk/PCAP                   ext4     defaults        1 2 >> /etc/fstab

mount -w $DB1
mount -w $PCAP1
# ------------------------------------------------------------------------------------------------

# 결과확인----------------------------------------------------------------------------------------
df -h
# ------------------------------------------------------------------------------------------------
